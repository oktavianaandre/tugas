var searchData=
[
  ['use_5flocal_5ffont_0',['USE_LOCAL_FONT',['../_m_d___m_a_x72xx_8h.html#a156ea396ee2a9dd550bc3a78ce65162b',1,'MD_MAX72xx.h']]]
];
