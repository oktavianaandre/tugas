<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-18 09:08:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'inventoryweb' C:\xampp\htdocs\wafo\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2024-06-18 09:08:50 --> Unable to connect to the database
