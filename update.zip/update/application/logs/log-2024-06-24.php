<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-24 02:46:45 --> Severity: error --> Exception: Call to a member function result() on array C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 20
ERROR - 2024-06-24 02:46:54 --> Severity: error --> Exception: Call to a member function result() on array C:\xampp1\htdocs\wafo\application\controllers\barangMasuk.php 20
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:37 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 98
ERROR - 2024-06-24 03:15:37 --> Severity: error --> Exception: Call to a member function data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 98
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:41 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 98
ERROR - 2024-06-24 03:15:41 --> Severity: error --> Exception: Call to a member function data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 98
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:21:16 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:21:16 --> Severity: Notice --> Undefined property: stdClass::$merk C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:21:16 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:21:16 --> Severity: Notice --> Undefined property: stdClass::$merk C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:21:44 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:21:44 --> Severity: Notice --> Undefined property: stdClass::$merk C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:21:44 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:21:44 --> Severity: Notice --> Undefined property: stdClass::$merk C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 06:39:49 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 06:39:49 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 06:39:49 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:41:20 --> Query error: Unknown column 'bk.id_jenis' in 'on clause' - Invalid query: SELECT *
FROM `barang_keluar` as `bk`
JOIN `barang` as `b` ON `b`.`id_barang` = `bk`.`id_barang`
JOIN `jenis` as `j` ON `j`.`id_jenis` = `bk`.`id_jenis`
ORDER BY `bk`.`id_barang_keluar` DESC
ERROR - 2024-06-24 06:43:19 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:44:30 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 06:44:30 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 06:44:30 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:44:31 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 06:44:31 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 06:44:32 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:45:15 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:45:40 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:50:14 --> Query error: Unknown column 'bm.id_jenis' in 'on clause' - Invalid query: SELECT *
FROM `barang_masuk` as `bm`
JOIN `barang` as `b` ON `b`.`id_barang` = `bm`.`id_barang`
JOIN `jenis` as `j` ON `j`.`id_jenis` = `bm`.`id_jenis`
JOIN `supplier` as `s` ON `s`.`id_supplier` = `bm`.`id_supplier`
ORDER BY `bm`.`id_barang_masuk` DESC
ERROR - 2024-06-24 06:50:51 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:52:22 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 74
ERROR - 2024-06-24 06:52:22 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 101
ERROR - 2024-06-24 06:53:17 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 06:53:20 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0002'
ERROR - 2024-06-24 06:53:35 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:53:37 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 74
ERROR - 2024-06-24 06:53:37 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 101
ERROR - 2024-06-24 06:54:19 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:54:25 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0002'
ERROR - 2024-06-24 06:54:28 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:55:28 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:55:29 --> Severity: Notice --> Undefined property: BarangMasuk::$satuan_model C:\xampp1\htdocs\wafo\application\controllers\barangMasuk.php 103
ERROR - 2024-06-24 06:55:29 --> Severity: error --> Exception: Call to a member function data() on null C:\xampp1\htdocs\wafo\application\controllers\barangMasuk.php 103
ERROR - 2024-06-24 06:55:32 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:55:49 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:55:51 --> Severity: Notice --> Undefined property: BarangMasuk::$satuan_model C:\xampp1\htdocs\wafo\application\controllers\barangMasuk.php 103
ERROR - 2024-06-24 06:55:51 --> Severity: error --> Exception: Call to a member function data() on null C:\xampp1\htdocs\wafo\application\controllers\barangMasuk.php 103
ERROR - 2024-06-24 06:57:14 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 06:57:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 06:57:14 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 06:57:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 06:57:42 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 06:58:28 --> Severity: Notice --> Undefined property: BarangMasuk::$satuan_model C:\xampp1\htdocs\wafo\application\controllers\barangMasuk.php 103
ERROR - 2024-06-24 06:58:28 --> Severity: error --> Exception: Call to a member function data() on null C:\xampp1\htdocs\wafo\application\controllers\barangMasuk.php 103
ERROR - 2024-06-24 06:58:53 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 06:58:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 06:58:53 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 06:58:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 06:59:13 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:59:16 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0002'
ERROR - 2024-06-24 06:59:23 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 06:59:25 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 06:59:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 06:59:25 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 06:59:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 06:59:54 --> Severity: Warning --> unlink(./assets/upload/barang/aqua.jpg): No such file or directory C:\xampp1\htdocs\wafo\application\controllers\barang.php 208
ERROR - 2024-06-24 07:00:00 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 07:00:03 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 07:00:05 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 07:00:07 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:00:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:00:07 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:00:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:00:10 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 07:40:38 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 07:40:40 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:40:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:40:40 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:40:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:40:47 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 07:41:20 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:41:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:41:20 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:41:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:41:50 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:41:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:41:51 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:41:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:41:55 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 07:44:08 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 07:44:09 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:44:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:44:09 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:44:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:45:38 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:45:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:45:38 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:45:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:45:45 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:45:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:45:45 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:45:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:45:49 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 07:45:50 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 07:45:51 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 79
ERROR - 2024-06-24 07:45:51 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:45:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 106
ERROR - 2024-06-24 07:45:54 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 07:47:01 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 07:47:19 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 07:47:24 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0005'
ERROR - 2024-06-24 07:47:31 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 07:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 07:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 07:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 07:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 07:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 07:58:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 07:59:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 07:59:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 07:59:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 07:59:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 07:59:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 07:59:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:00:48 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:01:02 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:01:31 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0005'
ERROR - 2024-06-24 08:01:39 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:02:32 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:06:02 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:06:13 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:06:17 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:06:26 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:06:36 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:12:02 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:12:09 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:12:14 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:19:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:19:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:19:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:19:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:19:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:19:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:19:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:19:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:19:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:19:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:19:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:19:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:20:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:20:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:20:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:20:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:20:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:20:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:22:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 80
ERROR - 2024-06-24 08:27:07 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:27:08 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:27:13 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:29:02 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:31:13 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 61
ERROR - 2024-06-24 08:31:13 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 61
ERROR - 2024-06-24 08:31:13 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 68
ERROR - 2024-06-24 08:31:13 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 68
ERROR - 2024-06-24 08:31:13 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:31:44 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 60
ERROR - 2024-06-24 08:31:44 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 60
ERROR - 2024-06-24 08:31:44 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 61
ERROR - 2024-06-24 08:31:44 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 61
ERROR - 2024-06-24 08:31:44 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 68
ERROR - 2024-06-24 08:31:44 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 68
ERROR - 2024-06-24 08:31:44 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:32:03 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 60
ERROR - 2024-06-24 08:32:03 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 60
ERROR - 2024-06-24 08:32:03 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 61
ERROR - 2024-06-24 08:32:03 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 61
ERROR - 2024-06-24 08:32:03 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 67
ERROR - 2024-06-24 08:32:03 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 67
ERROR - 2024-06-24 08:32:03 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 68
ERROR - 2024-06-24 08:32:03 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 68
ERROR - 2024-06-24 08:32:03 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:33:49 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:34:01 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:35:46 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:35:59 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:36:00 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:36:05 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:36:21 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:37:03 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:37:14 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:37:19 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:39:41 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:39:48 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:39:51 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:40:49 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 60
ERROR - 2024-06-24 08:40:49 --> Severity: Notice --> Trying to get property 'id_jenid' of non-object C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 60
ERROR - 2024-06-24 08:40:49 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 61
ERROR - 2024-06-24 08:40:49 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 61
ERROR - 2024-06-24 08:40:49 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:41:27 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 60
ERROR - 2024-06-24 08:41:27 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 89
ERROR - 2024-06-24 08:41:27 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:43:10 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 60
ERROR - 2024-06-24 08:43:10 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 89
ERROR - 2024-06-24 08:43:11 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:43:35 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:43:37 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 60
ERROR - 2024-06-24 08:43:37 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 89
ERROR - 2024-06-24 08:43:37 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:44:31 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 59
ERROR - 2024-06-24 08:44:31 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 88
ERROR - 2024-06-24 08:44:32 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:44:51 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 59
ERROR - 2024-06-24 08:44:51 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 88
ERROR - 2024-06-24 08:44:52 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:45:29 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:45:31 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 59
ERROR - 2024-06-24 08:45:31 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_ubah.php 88
ERROR - 2024-06-24 08:45:31 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:46:29 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:46:31 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:47:43 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_tambah.php 74
ERROR - 2024-06-24 08:47:43 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_tambah.php 101
ERROR - 2024-06-24 08:48:53 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:48:55 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:49:03 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:50:14 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:50:51 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0004'
ERROR - 2024-06-24 08:50:59 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0005'
ERROR - 2024-06-24 08:51:02 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:51:11 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0005'
ERROR - 2024-06-24 08:51:13 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 08:51:15 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0004'
ERROR - 2024-06-24 08:51:19 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:51:30 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:51:36 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:51:36 --> Severity: Notice --> Trying to get property 'id_jenid' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:51:36 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:52:40 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:52:40 --> Severity: Notice --> Trying to get property 'id_jenid' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:52:41 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:53:38 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:53:38 --> Severity: Notice --> Trying to get property 'id_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:53:38 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:53:54 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:53:54 --> Severity: Notice --> Trying to get property 'id_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:53:55 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:54:03 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:54:03 --> Severity: Notice --> Trying to get property 'id_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:54:03 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 61
ERROR - 2024-06-24 08:54:03 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 61
ERROR - 2024-06-24 08:54:04 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:54:27 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:54:27 --> Severity: Notice --> Trying to get property 'id_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:54:27 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 61
ERROR - 2024-06-24 08:54:27 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 61
ERROR - 2024-06-24 08:54:27 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:54:46 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:54:46 --> Severity: Notice --> Trying to get property 'id_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 08:54:46 --> Severity: Notice --> Undefined variable: j C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 61
ERROR - 2024-06-24 08:54:46 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 61
ERROR - 2024-06-24 08:54:46 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:55:12 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:56:39 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 59
ERROR - 2024-06-24 08:56:39 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 88
ERROR - 2024-06-24 08:56:39 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:56:46 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 59
ERROR - 2024-06-24 08:56:46 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 88
ERROR - 2024-06-24 08:56:46 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:57:35 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 59
ERROR - 2024-06-24 08:57:35 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 88
ERROR - 2024-06-24 08:57:35 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:57:45 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 08:57:49 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 59
ERROR - 2024-06-24 08:57:49 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 88
ERROR - 2024-06-24 08:57:49 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:58:59 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 59
ERROR - 2024-06-24 08:58:59 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 86
ERROR - 2024-06-24 08:58:59 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 08:59:29 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 59
ERROR - 2024-06-24 08:59:29 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 88
ERROR - 2024-06-24 08:59:29 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:01:10 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:01:24 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:02:03 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:02:04 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:02:08 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:03:11 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:03:13 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:03:16 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:03:52 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:04:02 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:04:10 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:04:15 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:06:41 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:07:34 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:07:37 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:07:40 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:07:46 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:08:01 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:08:03 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:18:12 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:18:14 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:18:31 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:18:45 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:18:47 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:20:12 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:20:19 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 09:29:51 --> Query error: Unknown column 'b.id_jenis' in 'on clause' - Invalid query: SELECT *
FROM `barang` as `b`
JOIN `jenis` as `j` ON `j`.`id_jenis` = `b`.`id_jenis`
JOIN `satuan` as `s` ON `s`.`id_satuan` = `b`.`id_satuan`
ORDER BY `b`.`id_barang` DESC
ERROR - 2024-06-24 09:31:10 --> Severity: Notice --> Undefined property: stdClass::$nama_jenis C:\xampp1\htdocs\wafo\application\views\barang\detail.php 85
ERROR - 2024-06-24 09:34:20 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barang\form_tambah.php 72
ERROR - 2024-06-24 09:44:51 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:47:18 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:49:13 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:49:17 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 09:49:26 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 09:49:30 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 74
ERROR - 2024-06-24 09:49:30 --> Severity: Notice --> Undefined variable: jmlJenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 101
ERROR - 2024-06-24 09:51:23 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 75
ERROR - 2024-06-24 09:51:23 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 81
ERROR - 2024-06-24 09:51:42 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 75
ERROR - 2024-06-24 09:51:42 --> Severity: Notice --> Undefined variable: merk C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 81
ERROR - 2024-06-24 09:52:54 --> Severity: Notice --> Undefined variable: jenis C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 75
ERROR - 2024-06-24 09:52:54 --> Severity: Notice --> Undefined variable: merk C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 81
ERROR - 2024-06-24 09:53:39 --> Severity: Notice --> Undefined variable: merk C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 81
ERROR - 2024-06-24 09:53:48 --> Severity: Notice --> Undefined variable: merk C:\xampp1\htdocs\wafo\application\views\barangMasuk\form_tambah.php 81
ERROR - 2024-06-24 09:58:54 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0007'
ERROR - 2024-06-24 10:10:24 --> Query error: Unknown column 'jenis' in 'field list' - Invalid query: INSERT INTO `barang_masuk` (`id_barang_masuk`, `id_barang`, `id_supplier`, `jumlah_masuk`, `tgl_masuk`, `jenis`, `merk`, `id_user`) VALUES ('BRG-M-0005', 'BRG-0007 - Oli - Suzuki', 'SPLY-0004', '33', '2024-06-24', 'Oli', NULL, 'USR-005')
ERROR - 2024-06-24 10:11:49 --> Query error: Column 'merk' cannot be null - Invalid query: INSERT INTO `barang_masuk` (`id_barang_masuk`, `id_barang`, `id_supplier`, `jumlah_masuk`, `tgl_masuk`, `jenis`, `merk`, `id_user`) VALUES ('BRG-M-0005', 'BRG-0007 - Oli - Suzuki', 'SPLY-0004', '33', '2024-06-24', 'Oli', NULL, 'USR-005')
ERROR - 2024-06-24 10:12:00 --> Query error: Column 'merk' cannot be null - Invalid query: INSERT INTO `barang_masuk` (`id_barang_masuk`, `id_barang`, `id_supplier`, `jumlah_masuk`, `tgl_masuk`, `jenis`, `merk`, `id_user`) VALUES ('BRG-M-0005', 'BRG-0007 - Oli - Suzuki', 'SPLY-0004', '33', '2024-06-24', 'Oli', NULL, 'USR-005')
ERROR - 2024-06-24 10:12:15 --> Query error: Column 'merk' cannot be null - Invalid query: INSERT INTO `barang_masuk` (`id_barang_masuk`, `id_barang`, `id_supplier`, `jumlah_masuk`, `tgl_masuk`, `jenis`, `merk`, `id_user`) VALUES ('BRG-M-0005', 'BRG-0007 - Oli - Suzuki', 'SPLY-0004', '33', '2024-06-24', 'Oli', NULL, 'USR-005')
ERROR - 2024-06-24 10:13:14 --> Query error: Column 'merk' cannot be null - Invalid query: INSERT INTO `barang_masuk` (`id_barang_masuk`, `id_barang`, `id_supplier`, `jumlah_masuk`, `tgl_masuk`, `jenis`, `merk`, `id_user`) VALUES ('BRG-M-0005', 'BRG-0007 - Oli - Suzuki', 'SPLY-0004', '33', '2024-06-24', 'Oli', NULL, 'USR-005')
ERROR - 2024-06-24 10:13:26 --> Query error: Unknown column 'bm.id_jenis' in 'on clause' - Invalid query: SELECT *
FROM `barang_masuk` as `bm`
JOIN `barang` as `b` ON `b`.`id_barang` = `bm`.`id_barang`
JOIN `jenis` as `j` ON `j`.`id_jenis` = `bm`.`id_jenis`
JOIN `supplier` as `s` ON `s`.`id_supplier` = `bm`.`id_supplier`
ORDER BY `bm`.`id_barang_masuk` DESC
ERROR - 2024-06-24 10:14:10 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 10:14:16 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 10:14:28 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 10:16:29 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 10:17:17 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 10:17:42 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'BRG-0006'
ERROR - 2024-06-24 10:17:52 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 10:18:11 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 10:18:39 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-24 10:41:15 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:41:15 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:43:07 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:43:07 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:43:36 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:43:36 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:46:47 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:46:47 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:46:49 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:46:49 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:46:51 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:46:51 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:48:03 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:48:03 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:50:26 --> Severity: Notice --> Undefined variable: merk C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 136
ERROR - 2024-06-24 10:50:26 --> Query error: Column 'merk' cannot be null - Invalid query: INSERT INTO `barang_keluar` (`id_barang_keluar`, `id_barang`, `jenis`, `merk`, `jumlah_keluar`, `tgl_keluar`, `id_user`) VALUES ('BRG-K-0001', 'BRG-0006', 'Sparepart', NULL, '1', '2024-06-24', 'USR-005')
ERROR - 2024-06-24 10:51:44 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:51:44 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:51:56 --> Severity: Notice --> Undefined property: stdClass::$id_jenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 10:51:56 --> Severity: Notice --> Undefined property: stdClass::$nama_jenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 61
ERROR - 2024-06-24 10:51:56 --> Severity: Notice --> Undefined property: stdClass::$id_jenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 67
ERROR - 2024-06-24 10:51:56 --> Severity: Notice --> Undefined property: stdClass::$nama_jenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 119
ERROR - 2024-06-24 10:51:56 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:51:56 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:51:59 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:51:59 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:52:17 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:52:17 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:52:19 --> Severity: Notice --> Undefined property: stdClass::$id_jenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 60
ERROR - 2024-06-24 10:52:19 --> Severity: Notice --> Undefined property: stdClass::$nama_jenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 61
ERROR - 2024-06-24 10:52:19 --> Severity: Notice --> Undefined property: stdClass::$id_jenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 67
ERROR - 2024-06-24 10:52:19 --> Severity: Notice --> Undefined property: stdClass::$nama_jenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 119
ERROR - 2024-06-24 10:52:19 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:52:19 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:52:21 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:52:21 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:52:28 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:52:28 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:52:40 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:52:40 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:53:18 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:53:18 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:53:27 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:53:27 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:53:40 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:53:40 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:53:43 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:53:43 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:54:06 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:54:06 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:55:40 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:55:40 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:55:41 --> Severity: Notice --> Undefined property: stdClass::$nama_jenis C:\xampp1\htdocs\wafo\application\views\barangKeluar\form_ubah.php 119
ERROR - 2024-06-24 10:55:41 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:55:41 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:55:55 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:55:55 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:55:59 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:55:59 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:57:07 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting elseif (T_ELSEIF) or else (T_ELSE) or endif (T_ENDIF) C:\xampp1\htdocs\wafo\application\views\templates\header.php 279
ERROR - 2024-06-24 10:57:26 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-24 10:57:26 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 55
