<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-19 10:48:48 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp1\htdocs\wafo\application\models\barang_model.php 18
ERROR - 2024-06-19 10:49:59 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp1\htdocs\wafo\application\models\barang_model.php 18
ERROR - 2024-06-19 10:50:01 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp1\htdocs\wafo\application\models\barang_model.php 18
ERROR - 2024-06-19 10:50:02 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp1\htdocs\wafo\application\models\barang_model.php 18
ERROR - 2024-06-19 10:50:02 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp1\htdocs\wafo\application\models\barang_model.php 18
ERROR - 2024-06-19 10:50:02 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp1\htdocs\wafo\application\models\barang_model.php 18
ERROR - 2024-06-19 10:54:33 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp1\htdocs\wafo\application\views\barang\form_tambah.php 212
ERROR - 2024-06-19 10:55:39 --> Severity: Notice --> Undefined variable: jmlMerk C:\xampp1\htdocs\wafo\application\views\barang\form_tambah.php 86
ERROR - 2024-06-19 10:56:07 --> Severity: Notice --> Undefined variable: Merk C:\xampp1\htdocs\wafo\application\views\barang\form_tambah.php 86
ERROR - 2024-06-19 10:56:13 --> Severity: Notice --> Undefined variable: merk C:\xampp1\htdocs\wafo\application\views\barang\form_tambah.php 86
ERROR - 2024-06-19 10:56:58 --> Severity: Notice --> Undefined variable: merk C:\xampp1\htdocs\wafo\application\views\barang\form_tambah.php 86
ERROR - 2024-06-19 10:57:16 --> Severity: Notice --> Undefined variable: merk C:\xampp1\htdocs\wafo\application\views\barang\form_tambah.php 86
ERROR - 2024-06-19 10:58:12 --> Severity: Notice --> Undefined variable: merk C:\xampp1\htdocs\wafo\application\views\barang\form_tambah.php 86
ERROR - 2024-06-19 10:59:10 --> Severity: Notice --> Undefined variable: merk C:\xampp1\htdocs\wafo\application\views\barang\form_tambah.php 91
ERROR - 2024-06-19 10:59:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp1\htdocs\wafo\application\views\barang\form_tambah.php 91
ERROR - 2024-06-19 11:24:32 --> Severity: Warning --> unlink(./assets/upload/barang/d4f130cc51185c56c9effcfa0b4a30a0.jpg): No such file or directory C:\xampp1\htdocs\wafo\application\controllers\barang.php 170
ERROR - 2024-06-19 11:24:47 --> Severity: Warning --> unlink(./assets/upload/barang/d4f130cc51185c56c9effcfa0b4a30a0.jpg): No such file or directory C:\xampp1\htdocs\wafo\application\controllers\barang.php 208
ERROR - 2024-06-19 11:25:39 --> Severity: Warning --> unlink(./assets/upload/pengguna/2023_03_29_13_50_IMG_1522.JPG): No such file or directory C:\xampp1\htdocs\wafo\application\controllers\user.php 194
