<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-25 08:24:14 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-25 08:24:16 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-25 08:24:16 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-25 08:28:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\wafo\application\views\barangKeluar\laporan.php 78
ERROR - 2024-06-25 08:28:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\wafo\application\views\barangKeluar\laporan.php 78
ERROR - 2024-06-25 08:35:21 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-25 08:35:35 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-25 08:35:49 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-25 08:36:03 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-25 08:36:15 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-25 08:36:18 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-25 08:36:18 --> Severity: error --> Exception: Call to a member function detail_data() on null C:\xampp\htdocs\wafo\application\controllers\barangKeluar.php 55
ERROR - 2024-06-25 08:36:21 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
ERROR - 2024-06-25 08:36:31 --> Query error: Unknown column 'id_barang' in 'where clause' - Invalid query: SELECT *
FROM `jenis`
WHERE `id_barang` = 'undefined'
