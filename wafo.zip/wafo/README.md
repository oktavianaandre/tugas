# Inventoryweb-ci3

features:

- Dashboard
- Profil
- User

akses(Admin)
Bisa Mengolah
---Master Data---
- Data Supplier
- Data Jenis Barang
- Data Satuan Barang
- Data Barang
- Data User

---Laporan---
- Laporan Barang Masuk
- Laporan Barang Keluar

akses(Gudang)
Bisa Mengolah
---Transaksi---
- Transaksi Barang Masuk
- Transaksi Barang Keluar

---Master Barang---
- Data Jenis Barang
- Data Satuan Barang
- Data Barang
- Data Supplier

akses(Manajer)
Melihat
---Master Barang---
- Data Barang


preview :

![login-inventoryweb](https://user-images.githubusercontent.com/47371845/116355365-f0ab1e00-a823-11eb-9c63-dabe8da1c919.PNG)

![inventoryweb](https://user-images.githubusercontent.com/47371845/116355430-0a4c6580-a824-11eb-9b0d-c52bdcdc2f36.PNG)

![supplier-inventoryweb](https://user-images.githubusercontent.com/47371845/116355565-38ca4080-a824-11eb-8f61-55576df915bf.PNG)

![satuan-inventoryweb](https://user-images.githubusercontent.com/47371845/116356111-079e4000-a825-11eb-9392-b59c7eff5f43.PNG)

![jenis-inventoryweb](https://user-images.githubusercontent.com/47371845/116356123-0cfb8a80-a825-11eb-96fb-32ac7f49f72d.PNG)

![barang-inventoryweb](https://user-images.githubusercontent.com/47371845/116356149-184eb600-a825-11eb-8899-4c20a83b137f.PNG)

![bm-inventoryweb](https://user-images.githubusercontent.com/47371845/116356183-26043b80-a825-11eb-9c81-26e5677b1d94.PNG)

![bk-inventoryweb](https://user-images.githubusercontent.com/47371845/116356202-2bfa1c80-a825-11eb-932d-60ef6132d77b.PNG)

![lapbm-inventoryweb](https://user-images.githubusercontent.com/47371845/116356234-35838480-a825-11eb-9bf5-2654f4db6d32.PNG)

![lpbk-inventoryweb](https://user-images.githubusercontent.com/47371845/116356259-3d432900-a825-11eb-86e1-54f5b74a0b8b.PNG)

![user-inventoryweb](https://user-images.githubusercontent.com/47371845/116356283-4633fa80-a825-11eb-93e3-e2b264291bdf.PNG)

![profil-inventoryweb](https://user-images.githubusercontent.com/47371845/116357307-8d6ebb00-a826-11eb-8dea-da03e642a0ae.PNG)

![printlapbm-inventoryweb](https://user-images.githubusercontent.com/47371845/116374663-b1d39300-a838-11eb-83e7-fa97b8333f3b.PNG)

![lprintapbk-inventoryweb](https://user-images.githubusercontent.com/47371845/116374695-b8faa100-a838-11eb-9a84-cddae978bcae.PNG)


