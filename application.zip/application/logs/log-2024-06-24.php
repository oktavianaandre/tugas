<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-24 02:46:45 --> Severity: error --> Exception: Call to a member function result() on array C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 20
ERROR - 2024-06-24 02:46:54 --> Severity: error --> Exception: Call to a member function result() on array C:\xampp1\htdocs\wafo\application\controllers\barangMasuk.php 20
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:01 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:37 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 98
ERROR - 2024-06-24 03:15:37 --> Severity: error --> Exception: Call to a member function data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 98
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:39 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:41 --> Severity: Notice --> Undefined property: BarangKeluar::$jenis_model C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 98
ERROR - 2024-06-24 03:15:41 --> Severity: error --> Exception: Call to a member function data() on null C:\xampp1\htdocs\wafo\application\controllers\barangKeluar.php 98
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'nama_jenis' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'id_barang' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Undefined variable: b C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:15:45 --> Severity: Notice --> Trying to get property 'merk' of non-object C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:21:16 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:21:16 --> Severity: Notice --> Undefined property: stdClass::$merk C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:21:16 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:21:16 --> Severity: Notice --> Undefined property: stdClass::$merk C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:21:44 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:21:44 --> Severity: Notice --> Undefined property: stdClass::$merk C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
ERROR - 2024-06-24 03:21:44 --> Severity: Notice --> Undefined property: stdClass::$jenis_barang C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 67
ERROR - 2024-06-24 03:21:44 --> Severity: Notice --> Undefined property: stdClass::$merk C:\xampp1\htdocs\wafo\application\views\barangKeluar\index.php 68
