<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Undefined variable: u C:\xampp1\htdocs\wafo\application\views\supplier\index.php 45
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Trying to get property 'id_supplier' of non-object C:\xampp1\htdocs\wafo\application\views\supplier\index.php 45
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Undefined variable: u C:\xampp1\htdocs\wafo\application\views\supplier\index.php 49
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Trying to get property 'id_supplier' of non-object C:\xampp1\htdocs\wafo\application\views\supplier\index.php 49
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Undefined variable: u C:\xampp1\htdocs\wafo\application\views\supplier\index.php 45
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Trying to get property 'id_supplier' of non-object C:\xampp1\htdocs\wafo\application\views\supplier\index.php 45
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Undefined variable: u C:\xampp1\htdocs\wafo\application\views\supplier\index.php 49
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Trying to get property 'id_supplier' of non-object C:\xampp1\htdocs\wafo\application\views\supplier\index.php 49
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Undefined variable: u C:\xampp1\htdocs\wafo\application\views\supplier\index.php 45
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Trying to get property 'id_supplier' of non-object C:\xampp1\htdocs\wafo\application\views\supplier\index.php 45
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Undefined variable: u C:\xampp1\htdocs\wafo\application\views\supplier\index.php 49
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Trying to get property 'id_supplier' of non-object C:\xampp1\htdocs\wafo\application\views\supplier\index.php 49
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Undefined variable: u C:\xampp1\htdocs\wafo\application\views\supplier\index.php 45
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Trying to get property 'id_supplier' of non-object C:\xampp1\htdocs\wafo\application\views\supplier\index.php 45
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Undefined variable: u C:\xampp1\htdocs\wafo\application\views\supplier\index.php 49
ERROR - 2024-06-10 10:23:34 --> Severity: Notice --> Trying to get property 'id_supplier' of non-object C:\xampp1\htdocs\wafo\application\views\supplier\index.php 49
ERROR - 2024-06-10 10:28:35 --> Severity: error --> Exception: syntax error, unexpected '}', expecting elseif (T_ELSEIF) or else (T_ELSE) or endif (T_ENDIF) C:\xampp1\htdocs\wafo\application\views\supplier\index.php 57
ERROR - 2024-06-10 10:40:45 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting elseif (T_ELSEIF) or else (T_ELSE) or endif (T_ENDIF) C:\xampp1\htdocs\wafo\application\views\supplier\index.php 206
